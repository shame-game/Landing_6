<!DOCTYPE html>
<html lang="vi" class="loading-site no-js">
<head>
	<meta charset="UTF-8" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel="pingback" href="https://zoa.vn/xmlrpc.php" />

	<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
<meta name='robots' content='noindex, follow' />
<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!-- This site is optimized with the Yoast SEO Premium plugin v20.7 (Yoast SEO v21.1) - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Dịch Vụ Xây Dựng Zalo Offical Account Chuẩn 5 Sao</title>
	<meta property="og:locale" content="vi_VN" />
	<meta property="og:title" content="Page not found - Dịch Vụ Xây Dựng Zalo Offical Account Chuẩn 5 Sao" />
	<meta property="og:site_name" content="Dịch Vụ Xây Dựng Zalo Offical Account Chuẩn 5 Sao" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://zoa.vn/#website","url":"https://zoa.vn/","name":"ZOA.vn - Dịch Vụ Xây Dựng Zalo Offical Account Chuẩn 5 Sao","description":"Dịch Vụ Triển Khai Zalo OA","publisher":{"@id":"https://zoa.vn/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://zoa.vn/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"vi"},{"@type":"Organization","@id":"https://zoa.vn/#organization","name":"ZOA","url":"https://zoa.vn/","logo":{"@type":"ImageObject","inLanguage":"vi","@id":"https://zoa.vn/#/schema/logo/image/","url":"https://zoa.vn/wp-content/uploads/2023/06/ZOA-900x900-1.png","contentUrl":"https://zoa.vn/wp-content/uploads/2023/06/ZOA-900x900-1.png","width":900,"height":900,"caption":"ZOA"},"image":{"@id":"https://zoa.vn/#/schema/logo/image/"},"sameAs":["https://www.facebook.com/zoa.vietnam","https://twitter.com/zoavietnam","https://www.tumblr.com/zoavietnam","https://sites.google.com/view/zoavietnam/","https://www.pinterest.com/zoavietnam/","https://www.youtube.com/@zoa.vietnam/","https://www.linkedin.com/in/zoavietnam","https://zoavietnam.blogspot.com/","https://www.instagram.com/zoavietnam/"]}]}</script>
	<!-- / Yoast SEO Premium plugin. -->


<link rel='dns-prefetch' href='//cdn.jsdelivr.net' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel='prefetch' href='https://zoa.vn/wp-content/themes/flatsome/assets/js/flatsome.js?ver=f2c57559524d9813afd4' />
<link rel='prefetch' href='https://zoa.vn/wp-content/themes/flatsome/assets/js/chunk.slider.js?ver=3.17.1.1' />
<link rel='prefetch' href='https://zoa.vn/wp-content/themes/flatsome/assets/js/chunk.popups.js?ver=3.17.1.1' />
<link rel='prefetch' href='https://zoa.vn/wp-content/themes/flatsome/assets/js/chunk.tooltips.js?ver=3.17.1.1' />
<link rel="alternate" type="application/rss+xml" title="Dòng thông tin Dịch Vụ Xây Dựng Zalo Offical Account Chuẩn 5 Sao &raquo;" href="https://zoa.vn/feed/" />
<link rel="alternate" type="application/rss+xml" title="Dòng phản hồi Dịch Vụ Xây Dựng Zalo Offical Account Chuẩn 5 Sao &raquo;" href="https://zoa.vn/comments/feed/" />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/zoa.vn\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.4.3"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<style id='wp-block-library-inline-css' type='text/css'>
:root{--wp-admin-theme-color:#007cba;--wp-admin-theme-color--rgb:0,124,186;--wp-admin-theme-color-darker-10:#006ba1;--wp-admin-theme-color-darker-10--rgb:0,107,161;--wp-admin-theme-color-darker-20:#005a87;--wp-admin-theme-color-darker-20--rgb:0,90,135;--wp-admin-border-width-focus:2px;--wp-block-synced-color:#7a00df;--wp-block-synced-color--rgb:122,0,223}@media (min-resolution:192dpi){:root{--wp-admin-border-width-focus:1.5px}}.wp-element-button{cursor:pointer}:root{--wp--preset--font-size--normal:16px;--wp--preset--font-size--huge:42px}:root .has-very-light-gray-background-color{background-color:#eee}:root .has-very-dark-gray-background-color{background-color:#313131}:root .has-very-light-gray-color{color:#eee}:root .has-very-dark-gray-color{color:#313131}:root .has-vivid-green-cyan-to-vivid-cyan-blue-gradient-background{background:linear-gradient(135deg,#00d084,#0693e3)}:root .has-purple-crush-gradient-background{background:linear-gradient(135deg,#34e2e4,#4721fb 50%,#ab1dfe)}:root .has-hazy-dawn-gradient-background{background:linear-gradient(135deg,#faaca8,#dad0ec)}:root .has-subdued-olive-gradient-background{background:linear-gradient(135deg,#fafae1,#67a671)}:root .has-atomic-cream-gradient-background{background:linear-gradient(135deg,#fdd79a,#004a59)}:root .has-nightshade-gradient-background{background:linear-gradient(135deg,#330968,#31cdcf)}:root .has-midnight-gradient-background{background:linear-gradient(135deg,#020381,#2874fc)}.has-regular-font-size{font-size:1em}.has-larger-font-size{font-size:2.625em}.has-normal-font-size{font-size:var(--wp--preset--font-size--normal)}.has-huge-font-size{font-size:var(--wp--preset--font-size--huge)}.has-text-align-center{text-align:center}.has-text-align-left{text-align:left}.has-text-align-right{text-align:right}#end-resizable-editor-section{display:none}.aligncenter{clear:both}.items-justified-left{justify-content:flex-start}.items-justified-center{justify-content:center}.items-justified-right{justify-content:flex-end}.items-justified-space-between{justify-content:space-between}.screen-reader-text{clip:rect(1px,1px,1px,1px);word-wrap:normal!important;border:0;-webkit-clip-path:inset(50%);clip-path:inset(50%);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.screen-reader-text:focus{clip:auto!important;background-color:#ddd;-webkit-clip-path:none;clip-path:none;color:#444;display:block;font-size:1em;height:auto;left:5px;line-height:normal;padding:15px 23px 14px;text-decoration:none;top:5px;width:auto;z-index:100000}html :where(.has-border-color){border-style:solid}html :where([style*=border-top-color]){border-top-style:solid}html :where([style*=border-right-color]){border-right-style:solid}html :where([style*=border-bottom-color]){border-bottom-style:solid}html :where([style*=border-left-color]){border-left-style:solid}html :where([style*=border-width]){border-style:solid}html :where([style*=border-top-width]){border-top-style:solid}html :where([style*=border-right-width]){border-right-style:solid}html :where([style*=border-bottom-width]){border-bottom-style:solid}html :where([style*=border-left-width]){border-left-style:solid}html :where(img[class*=wp-image-]){height:auto;max-width:100%}:where(figure){margin:0 0 1em}html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:var(--wp-admin--admin-bar--height,0px)}@media screen and (max-width:600px){html :where(.is-position-sticky){--wp-admin--admin-bar--position-offset:0px}}
</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://zoa.vn/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.8' type='text/css' media='all' />
<link rel='stylesheet' id='kk-star-ratings-css' href='https://zoa.vn/wp-content/plugins/kk-star-ratings/src/core/public/css/kk-star-ratings.min.css?ver=5.4.5' type='text/css' media='all' />
<link rel='stylesheet' id='fancybox-css' href='https://zoa.vn/wp-content/plugins/easy-fancybox/fancybox/1.5.4/jquery.fancybox.min.css?ver=6.4.3' type='text/css' media='screen' />
<link rel='stylesheet' id='flatsome-main-css' href='https://zoa.vn/wp-content/themes/flatsome/assets/css/flatsome.css?ver=3.17.1.1' type='text/css' media='all' />
<style id='flatsome-main-inline-css' type='text/css'>
@font-face {
				font-family: "fl-icons";
				font-display: block;
				src: url(https://zoa.vn/wp-content/themes/flatsome/assets/css/icons/fl-icons.eot?v=3.17.1.1);
				src:
					url(https://zoa.vn/wp-content/themes/flatsome/assets/css/icons/fl-icons.eot#iefix?v=3.17.1.1) format("embedded-opentype"),
					url(https://zoa.vn/wp-content/themes/flatsome/assets/css/icons/fl-icons.woff2?v=3.17.1.1) format("woff2"),
					url(https://zoa.vn/wp-content/themes/flatsome/assets/css/icons/fl-icons.ttf?v=3.17.1.1) format("truetype"),
					url(https://zoa.vn/wp-content/themes/flatsome/assets/css/icons/fl-icons.woff?v=3.17.1.1) format("woff"),
					url(https://zoa.vn/wp-content/themes/flatsome/assets/css/icons/fl-icons.svg?v=3.17.1.1#fl-icons) format("svg");
			}
</style>
<link rel='stylesheet' id='flatsome-style-css' href='https://zoa.vn/wp-content/themes/flatsome-child/style.css?ver=3.0' type='text/css' media='all' />
<link rel='stylesheet' id='flatsome-googlefonts-css' href='//fonts.googleapis.com/css?family=Roboto%3Aregular%2C700%2C500%2C700%2C700&#038;display=swap&#038;ver=3.9' type='text/css' media='all' />
<script type="text/javascript" src="https://zoa.vn/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://zoa.vn/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="https://api.w.org/" href="https://zoa.vn/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://zoa.vn/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.4.3" />
<!-- HFCM by 99 Robots - Snippet # 1: Code GG Analytics -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-FB41Z385DP"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-FB41Z385DP');
</script>
<!-- /end HFCM by 99 Robots -->
<style>.bg{opacity: 0; transition: opacity 1s; -webkit-transition: opacity 1s;} .bg-loaded{opacity: 1;}</style><!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '248853561192091');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=248853561192091&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

<script id="omiLiveTalk" type="text/javascript" src="https://cdn.omicrm.com/script/livetalk/main.js#domain=dinhthaiha;"></script>
<meta name="google-site-verification" content="AqqDOu0R-FJ2Sy_kZIHRlvt7t0MLBgHLj3D1ZPRLzC8" />
			<style id="wpsp-style-frontend"></style>
			<link rel="icon" href="https://zoa.vn/wp-content/uploads/2023/06/cropped-ZOA-900x900-1-60x60.png" sizes="32x32" />
<link rel="icon" href="https://zoa.vn/wp-content/uploads/2023/06/cropped-ZOA-900x900-1-300x300.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://zoa.vn/wp-content/uploads/2023/06/cropped-ZOA-900x900-1-300x300.png" />
<meta name="msapplication-TileImage" content="https://zoa.vn/wp-content/uploads/2023/06/cropped-ZOA-900x900-1-300x300.png" />
<style id="custom-css" type="text/css">:root {--primary-color: #0068ff;}.header-main{height: 90px}#logo img{max-height: 90px}#logo{width:200px;}.header-bottom{min-height: 55px}.header-top{min-height: 47px}.transparent .header-main{height: 90px}.transparent #logo img{max-height: 90px}.has-transparent + .page-title:first-of-type,.has-transparent + #main > .page-title,.has-transparent + #main > div > .page-title,.has-transparent + #main .page-header-wrapper:first-of-type .page-title{padding-top: 120px;}.header.show-on-scroll,.stuck .header-main{height:70px!important}.stuck #logo img{max-height: 70px!important}.header-bottom {background-color: #f1f1f1}.top-bar-nav > li > a{line-height: 16px }.stuck .header-main .nav > li > a{line-height: 50px }.header-bottom-nav > li > a{line-height: 16px }@media (max-width: 549px) {.header-main{height: 70px}#logo img{max-height: 70px}}/* Color */.accordion-title.active, .has-icon-bg .icon .icon-inner,.logo a, .primary.is-underline, .primary.is-link, .badge-outline .badge-inner, .nav-outline > li.active> a,.nav-outline >li.active > a, .cart-icon strong,[data-color='primary'], .is-outline.primary{color: #0068ff;}/* Color !important */[data-text-color="primary"]{color: #0068ff!important;}/* Background Color */[data-text-bg="primary"]{background-color: #0068ff;}/* Background */.scroll-to-bullets a,.featured-title, .label-new.menu-item > a:after, .nav-pagination > li > .current,.nav-pagination > li > span:hover,.nav-pagination > li > a:hover,.has-hover:hover .badge-outline .badge-inner,button[type="submit"], .button.wc-forward:not(.checkout):not(.checkout-button), .button.submit-button, .button.primary:not(.is-outline),.featured-table .title,.is-outline:hover, .has-icon:hover .icon-label,.nav-dropdown-bold .nav-column li > a:hover, .nav-dropdown.nav-dropdown-bold > li > a:hover, .nav-dropdown-bold.dark .nav-column li > a:hover, .nav-dropdown.nav-dropdown-bold.dark > li > a:hover, .header-vertical-menu__opener ,.is-outline:hover, .tagcloud a:hover,.grid-tools a, input[type='submit']:not(.is-form), .box-badge:hover .box-text, input.button.alt,.nav-box > li > a:hover,.nav-box > li.active > a,.nav-pills > li.active > a ,.current-dropdown .cart-icon strong, .cart-icon:hover strong, .nav-line-bottom > li > a:before, .nav-line-grow > li > a:before, .nav-line > li > a:before,.banner, .header-top, .slider-nav-circle .flickity-prev-next-button:hover svg, .slider-nav-circle .flickity-prev-next-button:hover .arrow, .primary.is-outline:hover, .button.primary:not(.is-outline), input[type='submit'].primary, input[type='submit'].primary, input[type='reset'].button, input[type='button'].primary, .badge-inner{background-color: #0068ff;}/* Border */.nav-vertical.nav-tabs > li.active > a,.scroll-to-bullets a.active,.nav-pagination > li > .current,.nav-pagination > li > span:hover,.nav-pagination > li > a:hover,.has-hover:hover .badge-outline .badge-inner,.accordion-title.active,.featured-table,.is-outline:hover, .tagcloud a:hover,blockquote, .has-border, .cart-icon strong:after,.cart-icon strong,.blockUI:before, .processing:before,.loading-spin, .slider-nav-circle .flickity-prev-next-button:hover svg, .slider-nav-circle .flickity-prev-next-button:hover .arrow, .primary.is-outline:hover{border-color: #0068ff}.nav-tabs > li.active > a{border-top-color: #0068ff}.widget_shopping_cart_content .blockUI.blockOverlay:before { border-left-color: #0068ff }.woocommerce-checkout-review-order .blockUI.blockOverlay:before { border-left-color: #0068ff }/* Fill */.slider .flickity-prev-next-button:hover svg,.slider .flickity-prev-next-button:hover .arrow{fill: #0068ff;}/* Focus */.primary:focus-visible, .submit-button:focus-visible, button[type="submit"]:focus-visible { outline-color: #0068ff!important; }/* Background Color */[data-icon-label]:after, .secondary.is-underline:hover,.secondary.is-outline:hover,.icon-label,.button.secondary:not(.is-outline),.button.alt:not(.is-outline), .badge-inner.on-sale, .button.checkout, .single_add_to_cart_button, .current .breadcrumb-step{ background-color:#4751a6; }[data-text-bg="secondary"]{background-color: #4751a6;}/* Color */.secondary.is-underline,.secondary.is-link, .secondary.is-outline,.stars a.active, .star-rating:before, .woocommerce-page .star-rating:before,.star-rating span:before, .color-secondary{color: #4751a6}/* Color !important */[data-text-color="secondary"]{color: #4751a6!important;}/* Border */.secondary.is-outline:hover{border-color:#4751a6}/* Focus */.secondary:focus-visible, .alt:focus-visible { outline-color: #4751a6!important; }.success.is-underline:hover,.success.is-outline:hover,.success{background-color: #2da545}.success-color, .success.is-link, .success.is-outline{color: #2da545;}.success-border{border-color: #2da545!important;}/* Color !important */[data-text-color="success"]{color: #2da545!important;}/* Background Color */[data-text-bg="success"]{background-color: #2da545;}body{color: #343436}h1,h2,h3,h4,h5,h6,.heading-font{color: #343436;}body{font-size: 100%;}@media screen and (max-width: 549px){body{font-size: 100%;}}body{font-family: Roboto, sans-serif;}body {font-weight: 500;font-style: normal;}.nav > li > a {font-family: Roboto, sans-serif;}.mobile-sidebar-levels-2 .nav > li > ul > li > a {font-family: Roboto, sans-serif;}.nav > li > a,.mobile-sidebar-levels-2 .nav > li > ul > li > a {font-weight: 700;font-style: normal;}h1,h2,h3,h4,h5,h6,.heading-font, .off-canvas-center .nav-sidebar.nav-vertical > li > a{font-family: Roboto, sans-serif;}h1,h2,h3,h4,h5,h6,.heading-font,.banner h1,.banner h2 {font-weight: 700;font-style: normal;}.alt-font{font-family: Roboto, sans-serif;}.alt-font {font-weight: 700!important;font-style: normal!important;}a:hover{color: #343436;}.tagcloud a:hover{border-color: #343436;background-color: #343436;}.nav-vertical-fly-out > li + li {border-top-width: 1px; border-top-style: solid;}/* Custom CSS */.hotline-phone-ring-wrap {position: fixed;bottom: 0;left: 0;z-index: 999999;}.hotline-phone-ring {position: relative;visibility: visible;background-color: transparent;width: 110px;height: 110px;cursor: pointer;z-index: 11;-webkit-backface-visibility: hidden;-webkit-transform: translateZ(0);transition: visibility .5s;left: 0;bottom: 0;display: block;}.hotline-phone-ring-circle {width: 85px;height: 85px;top: 10px;left: 10px;position: absolute;background-color: transparent;border-radius: 100%;border: 2px solid #e60808;-webkit-animation: phonering-alo-circle-anim 1.2s infinite ease-in-out;animation: phonering-alo-circle-anim 1.2s infinite ease-in-out;transition: all .5s;-webkit-transform-origin: 50% 50%;-ms-transform-origin: 50% 50%;transform-origin: 50% 50%;opacity: 0.5;}.hotline-phone-ring-circle-fill {width: 55px;height: 55px;top: 25px;left: 25px;position: absolute;background-color: rgba(230, 8, 8, 0.7);border-radius: 100%;border: 2px solid transparent;-webkit-animation: phonering-alo-circle-fill-anim 2.3s infinite ease-in-out;animation: phonering-alo-circle-fill-anim 2.3s infinite ease-in-out;transition: all .5s;-webkit-transform-origin: 50% 50%;-ms-transform-origin: 50% 50%;transform-origin: 50% 50%;}.hotline-phone-ring-img-circle {background-color: #e60808;width: 33px;height: 33px;top: 37px;left: 37px;position: absolute;background-size: 20px;border-radius: 100%;border: 2px solid transparent;-webkit-animation: phonering-alo-circle-img-anim 1s infinite ease-in-out;animation: phonering-alo-circle-img-anim 1s infinite ease-in-out;-webkit-transform-origin: 50% 50%;-ms-transform-origin: 50% 50%;transform-origin: 50% 50%;display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;align-items: center;justify-content: center;}.hotline-phone-ring-img-circle .pps-btn-img {display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;}.hotline-phone-ring-img-circle .pps-btn-img img {width: 20px;height: 20px;}.hotline-bar {position: absolute;background: rgba(230, 8, 8, 0.75);height: 40px;width: 180px;line-height: 40px;border-radius: 3px;padding: 0 10px;background-size: 100%;cursor: pointer;transition: all 0.8s;-webkit-transition: all 0.8s;z-index: 9;box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.1);border-radius: 50px !important;/* width: 175px !important; */left: 33px;bottom: 37px;}.hotline-bar > a {color: #fff;text-decoration: none;font-size: 15px;font-weight: bold;text-indent: 50px;display: block;letter-spacing: 1px;line-height: 40px;font-family: Arial;}.hotline-bar > a:hover,.hotline-bar > a:active {color: #fff;}@-webkit-keyframes phonering-alo-circle-anim {0% {-webkit-transform: rotate(0) scale(0.5) skew(1deg);-webkit-opacity: 0.1;}30% {-webkit-transform: rotate(0) scale(0.7) skew(1deg);-webkit-opacity: 0.5;}100% {-webkit-transform: rotate(0) scale(1) skew(1deg);-webkit-opacity: 0.1;}}@-webkit-keyframes phonering-alo-circle-fill-anim {0% {-webkit-transform: rotate(0) scale(0.7) skew(1deg);opacity: 0.6;}50% {-webkit-transform: rotate(0) scale(1) skew(1deg);opacity: 0.6;}100% {-webkit-transform: rotate(0) scale(0.7) skew(1deg);opacity: 0.6;}}@-webkit-keyframes phonering-alo-circle-img-anim {0% {-webkit-transform: rotate(0) scale(1) skew(1deg);}10% {-webkit-transform: rotate(-25deg) scale(1) skew(1deg);}20% {-webkit-transform: rotate(25deg) scale(1) skew(1deg);}30% {-webkit-transform: rotate(-25deg) scale(1) skew(1deg);}40% {-webkit-transform: rotate(25deg) scale(1) skew(1deg);}50% {-webkit-transform: rotate(0) scale(1) skew(1deg);}100% {-webkit-transform: rotate(0) scale(1) skew(1deg);}}@media (max-width: 768px) {.hotline-bar {display: none;}}/***********basic************/ /*Form width*/.wpcf7 {text-align: center;width: 100%;border-radius: 15px;} /*Input Field widths*/.wpcf7-text, .wpcf7-textarea {width: 100%;border: 1px solid #e4e4e4;} .wpcf7-text { height: 50px;padding-left: 10px;}.wpcf7-text:focus, .wpcf7-textarea:focus {border-color: #129FEA;} /*Label Font*/.wpcf7-form p {font-size: 16px;font-family: 'Roboto', sans-serif;} /*Submit button Font*/.wpcf7-submit {width: 85%;font-size: 15px !important;color: #fff !important;padding: 20px;} /*Submit button Hover*/.wpcf7-submit:hover {background: #3b86b0 !important;} /*Response messages - Error & Success*/.wpcf7-response-output {margin-bottom: 30px !important;} /***********borders************/ /*Form border*/.wpcf7 {padding: 20px 25px !important;padding-bottom: 0px !important;} /*Input Field borders*/.wpcf7-text:focus, .wpcf7-textarea:focus {border-color: #8F8F8F !important;} /*Submit button Background*/.wpcf7-submit {background: #7E7E7E !important;color: #fff !important;} /*Submit button Hover*/.wpcf7-submit:hover {background: #5F5F5F !important;} /***********colors************/ /*Submit button background & border*/.wpcf7-submit {background-color: #2075ef !important;border: 2px solid #5A5050 !important;color: #5A5050 !important;font-weight: bold !important;} /*Submit button Hover styles*/.wpcf7-submit:hover {background-color: rgba(29, 39, 49, 0.66) !important;border-color: #4CAF50 !important;color: #4CAF50 !important;} /*Label Text color*/.wpcf7-form p {color: #FFF;} .wpcf7-form label{/*display: none;*/} /*Input Field Text color*/.wpcf7-text, .wpcf7-textarea {color: #777;} /****background-images********/ /*Form background*/.wpcf7 {/*background-image: url(https://i.imgur.com/iAFPf0G.jpg);*/background-color: #1670f71f;background-position: center;background-size: cover;} /*Label Text color*/.wpcf7-form p {/*display: none;*//*color: #000000;*/} /*Submit button background & border*/.wpcf7-submit {border: 2px solid #FFFFFF !important;color: #FFFFFF !important;} /*Submit button Hover styles*/.wpcf7-submit:hover {border-color: transparent !important;background-color: rgba(0, 0, 0, 0.2) !important;color: #FFFFFF !important;} /*Input Field border*/.wpcf7-text:focus, .wpcf7-textarea:focus {border-color: #5A3D3D !important;}.hotline-phone-ring-wrap {position: fixed;bottom: 0;left: 0;z-index: 999999;}.hotline-phone-ring {position: relative;visibility: visible;background-color: transparent;width: 110px;height: 110px;cursor: pointer;z-index: 11;-webkit-backface-visibility: hidden;-webkit-transform: translateZ(0);transition: visibility .5s;left: 0;bottom: 0;display: block;}.hotline-phone-ring-circle {width: 85px;height: 85px;top: 10px;left: 10px;position: absolute;background-color: transparent;border-radius: 100%;border: 2px solid #e60808;-webkit-animation: phonering-alo-circle-anim 1.2s infinite ease-in-out;animation: phonering-alo-circle-anim 1.2s infinite ease-in-out;transition: all .5s;-webkit-transform-origin: 50% 50%;-ms-transform-origin: 50% 50%;transform-origin: 50% 50%;opacity: 0.5;}.hotline-phone-ring-circle-fill {width: 55px;height: 55px;top: 25px;left: 25px;position: absolute;background-color: rgba(230, 8, 8, 0.7);border-radius: 100%;border: 2px solid transparent;-webkit-animation: phonering-alo-circle-fill-anim 2.3s infinite ease-in-out;animation: phonering-alo-circle-fill-anim 2.3s infinite ease-in-out;transition: all .5s;-webkit-transform-origin: 50% 50%;-ms-transform-origin: 50% 50%;transform-origin: 50% 50%;}.hotline-phone-ring-img-circle {background-color: #e60808;width: 33px;height: 33px;top: 37px;left: 37px;position: absolute;background-size: 20px;border-radius: 100%;border: 2px solid transparent;-webkit-animation: phonering-alo-circle-img-anim 1s infinite ease-in-out;animation: phonering-alo-circle-img-anim 1s infinite ease-in-out;-webkit-transform-origin: 50% 50%;-ms-transform-origin: 50% 50%;transform-origin: 50% 50%;display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;align-items: center;justify-content: center;}.hotline-phone-ring-img-circle .pps-btn-img {display: -webkit-box;display: -webkit-flex;display: -ms-flexbox;display: flex;}.hotline-phone-ring-img-circle .pps-btn-img img {width: 20px;height: 20px;}.hotline-bar {position: absolute;background: rgba(230, 8, 8, 0.75);height: 40px;width: 180px;line-height: 40px;border-radius: 3px;padding: 0 10px;background-size: 100%;cursor: pointer;transition: all 0.8s;-webkit-transition: all 0.8s;z-index: 9;box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.1);border-radius: 50px !important;/* width: 175px !important; */left: 33px;bottom: 37px;}.hotline-bar > a {color: #fff;text-decoration: none;font-size: 15px;font-weight: bold;text-indent: 50px;display: block;letter-spacing: 1px;line-height: 40px;font-family: Arial;}.hotline-bar > a:hover,.hotline-bar > a:active {color: #fff;}@-webkit-keyframes phonering-alo-circle-anim {0% {-webkit-transform: rotate(0) scale(0.5) skew(1deg);-webkit-opacity: 0.1;}30% {-webkit-transform: rotate(0) scale(0.7) skew(1deg);-webkit-opacity: 0.5;}100% {-webkit-transform: rotate(0) scale(1) skew(1deg);-webkit-opacity: 0.1;}}@-webkit-keyframes phonering-alo-circle-fill-anim {0% {-webkit-transform: rotate(0) scale(0.7) skew(1deg);opacity: 0.6;}50% {-webkit-transform: rotate(0) scale(1) skew(1deg);opacity: 0.6;}100% {-webkit-transform: rotate(0) scale(0.7) skew(1deg);opacity: 0.6;}}@-webkit-keyframes phonering-alo-circle-img-anim {0% {-webkit-transform: rotate(0) scale(1) skew(1deg);}10% {-webkit-transform: rotate(-25deg) scale(1) skew(1deg);}20% {-webkit-transform: rotate(25deg) scale(1) skew(1deg);}30% {-webkit-transform: rotate(-25deg) scale(1) skew(1deg);}40% {-webkit-transform: rotate(25deg) scale(1) skew(1deg);}50% {-webkit-transform: rotate(0) scale(1) skew(1deg);}100% {-webkit-transform: rotate(0) scale(1) skew(1deg);}}@media (max-width: 768px) {.hotline-bar {display: none;}}.button.icon.circle{bottom: 105px;}.nav > li > a{color: black;}.yoast-breadcrumbs{font-weight: bold;padding-bottom:20pt;margin-top: -37pt;font-size: 12px;font-family: sans-serif;}.rt-reading-time{padding-bottom: 20pt;}.label-new.menu-item > a:after{content:"New";}.label-hot.menu-item > a:after{content:"Hot";}.label-sale.menu-item > a:after{content:"Sale";}.label-popular.menu-item > a:after{content:"Popular";}</style></head>

<body class="error404 wp-schema-pro-2.7.7 lightbox nav-dropdown-has-arrow nav-dropdown-has-shadow nav-dropdown-has-border">


<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

<div id="wrapper">

	
	<header id="header" class="header has-sticky sticky-jump">
		<div class="header-wrapper">
			<div id="top-bar" class="header-top hide-for-sticky nav-dark flex-has-center hide-for-medium">
    <div class="flex-row container">
      <div class="flex-col hide-for-medium flex-left">
          <ul class="nav nav-left medium-nav-center nav-small  nav-divided">
                        </ul>
      </div>

      <div class="flex-col hide-for-medium flex-center">
          <ul class="nav nav-center nav-small  nav-divided">
              <li class="html custom html_topbar_right"><strong class="uppercase">Tặng 10.000 tin nhắn ZNS miễn phí</strong></li><li class="html header-button-1">
	<div class="header-button">
	<a href="https://zoa.vn/#qua-tang" class="button success is-bevel"  style="border-radius:7px;">
    <span>Xem Ngay!</span>
  </a>
	</div>
</li>


          </ul>
      </div>

      <div class="flex-col hide-for-medium flex-right">
         <ul class="nav top-bar-nav nav-right nav-small  nav-divided">
              <li class="html header-social-icons ml-0">
	<div class="social-icons follow-icons" ><a href="https://www.facebook.com/zoa.vietnam" target="_blank" rel="noopener noreferrer nofollow" data-label="Facebook" class="icon plain facebook tooltip" title="Follow on Facebook" aria-label="Follow on Facebook" ><i class="icon-facebook" ></i></a><a href="https://www.instagram.com/zoavietnam/" target="_blank" rel="noopener noreferrer nofollow" data-label="Instagram" class="icon plain instagram tooltip" title="Follow on Instagram" aria-label="Follow on Instagram" ><i class="icon-instagram" ></i></a><a href="https://twitter.com/zoavietnam" data-label="Twitter" target="_blank" rel="noopener noreferrer nofollow" class="icon plain twitter tooltip" title="Follow on Twitter" aria-label="Follow on Twitter" ><i class="icon-twitter" ></i></a><a href="https://www.pinterest.com/zoavietnam/" data-label="Pinterest" target="_blank" rel="noopener noreferrer nofollow" class="icon plain pinterest tooltip" title="Follow on Pinterest" aria-label="Follow on Pinterest" ><i class="icon-pinterest" ></i></a><a href="https://www.youtube.com/@zoa.vietnam/" data-label="YouTube" target="_blank" rel="noopener noreferrer nofollow" class="icon plain youtube tooltip" title="Follow on YouTube" aria-label="Follow on YouTube" ><i class="icon-youtube" ></i></a></div></li>
          </ul>
      </div>

      
    </div>
</div>
<div id="masthead" class="header-main ">
      <div class="header-inner flex-row container logo-left medium-logo-center" role="navigation">

          <!-- Logo -->
          <div id="logo" class="flex-col logo">
            
<!-- Header logo -->
<a href="https://zoa.vn/" title="Dịch Vụ Xây Dựng Zalo Offical Account Chuẩn 5 Sao - Dịch Vụ Triển Khai Zalo OA" rel="home">
		<img width="916" height="284" src="https://zoa.vn/wp-content/uploads/2023/06/ZOA-916x284-2.png" class="header_logo header-logo" alt="Dịch Vụ Xây Dựng Zalo Offical Account Chuẩn 5 Sao"/><img  width="916" height="284" src="https://zoa.vn/wp-content/uploads/2023/06/ZOA-916x284-2.png" class="header-logo-dark" alt="Dịch Vụ Xây Dựng Zalo Offical Account Chuẩn 5 Sao"/></a>
          </div>

          <!-- Mobile Left Elements -->
          <div class="flex-col show-for-medium flex-left">
            <ul class="mobile-nav nav nav-left ">
              <li class="nav-icon has-icon">
  		<a href="#" data-open="#main-menu" data-pos="left" data-bg="main-menu-overlay" data-color="" class="is-small" aria-label="Menu" aria-controls="main-menu" aria-expanded="false">

		  <i class="icon-menu" ></i>
		  		</a>
	</li>
            </ul>
          </div>

          <!-- Left Elements -->
          <div class="flex-col hide-for-medium flex-left
            flex-grow">
            <ul class="header-nav header-nav-main nav nav-left  nav-uppercase" >
              <li id="menu-item-71" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-71 menu-item-design-default"><a href="https://zoa.vn/" class="nav-top-link">ZOA.vn</a></li>
<li id="menu-item-67" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-67 menu-item-design-default"><a href="#" class="nav-top-link">Bảng giá</a></li>
<li id="menu-item-69" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-69 menu-item-design-default has-dropdown"><a href="#" class="nav-top-link" aria-expanded="false" aria-haspopup="menu">Tìm hiểu<i class="icon-angle-down" ></i></a>
<ul class="sub-menu nav-dropdown nav-dropdown-default">
	<li id="menu-item-72" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-72"><a href="#">Hướng dẫn sử dụng</a></li>
	<li id="menu-item-73" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-73"><a href="#">Câu chuyện thành công</a></li>
	<li id="menu-item-74" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-74"><a href="#">Chính sách</a></li>
</ul>
</li>
<li id="menu-item-70" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70 menu-item-design-default"><a href="#" class="nav-top-link">Dịch vụ khác</a></li>
<li id="menu-item-68" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-68 menu-item-design-default"><a href="#" class="nav-top-link">Liên hệ</a></li>
<li id="menu-item-65" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-65 menu-item-design-default"><a href="https://zoa.vn/blog/" class="nav-top-link">BLOG</a></li>
            </ul>
          </div>

          <!-- Right Elements -->
          <div class="flex-col hide-for-medium flex-right">
            <ul class="header-nav header-nav-main nav nav-right  nav-uppercase">
              <li class="header-search header-search-dropdown has-icon has-dropdown menu-item-has-children">
		<a href="#" aria-label="Search" class="is-small"><i class="icon-search" ></i></a>
		<ul class="nav-dropdown nav-dropdown-default">
	 	<li class="header-search-form search-form html relative has-icon">
	<div class="header-search-form-wrapper">
		<div class="searchform-wrapper ux-search-box relative is-normal"><form method="get" class="searchform" action="https://zoa.vn/" role="search">
		<div class="flex-row relative">
			<div class="flex-col flex-grow">
	   	   <input type="search" class="search-field mb-0" name="s" value="" id="s" placeholder="Search&hellip;" />
			</div>
			<div class="flex-col">
				<button type="submit" class="ux-search-submit submit-button secondary button icon mb-0" aria-label="Submit">
					<i class="icon-search" ></i>				</button>
			</div>
		</div>
    <div class="live-search-results text-left z-top"></div>
</form>
</div>	</div>
</li>
	</ul>
</li>
            </ul>
          </div>

          <!-- Mobile Right Elements -->
          <div class="flex-col show-for-medium flex-right">
            <ul class="mobile-nav nav nav-right ">
                          </ul>
          </div>

      </div>

            <div class="container"><div class="top-divider full-width"></div></div>
      </div>

<div class="header-bg-container fill"><div class="header-bg-image fill"></div><div class="header-bg-color fill"></div></div>		</div>
	</header>

	
	<main id="main" class="">
	<div id="primary" class="content-area">
		<main id="main" class="site-main container pt" role="main">
			<section class="error-404 not-found mt mb">
				<div class="row">
					<div class="col medium-3"><span class="header-font" style="font-size: 6em; font-weight: bold; opacity: .3">404</span></div>
					<div class="col medium-9">
						<header class="page-title">
							<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
						</header>
						<div class="page-content">
							<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>
							<form method="get" class="searchform" action="https://zoa.vn/" role="search">
		<div class="flex-row relative">
			<div class="flex-col flex-grow">
	   	   <input type="search" class="search-field mb-0" name="s" value="" id="s" placeholder="Search&hellip;" />
			</div>
			<div class="flex-col">
				<button type="submit" class="ux-search-submit submit-button secondary button icon mb-0" aria-label="Submit">
					<i class="icon-search" ></i>				</button>
			</div>
		</div>
    <div class="live-search-results text-left z-top"></div>
</form>
						</div>
					</div>
				</div>
			</section>
		</main>
	</div>

</main>

<footer id="footer" class="footer-wrapper">

		<section class="section dark" id="section_845689956">
		<div class="bg section-bg fill bg-fill  bg-loaded" >

			
			
			

		</div>

		

		<div class="section-content relative">
			

	<div id="gap-1789876931" class="gap-element clearfix" style="display:block; height:auto;">
		
<style>
#gap-1789876931 {
  padding-top: 30px;
}
</style>
	</div>
	

<div class="row"  id="row-1568497926">


	<div id="col-438395474" class="col medium-12 small-12 large-4"  >
				<div class="col-inner"  >
			
			

	<div class="img has-hover x md-x lg-x y md-y lg-y" id="image_229687962">
								<div class="img-inner dark" >
			<img width="916" height="284" src="https://zoa.vn/wp-content/uploads/2023/06/ZOA-916x284-1.png" class="attachment-large size-large" alt="Logo Zalo OA" decoding="async" loading="lazy" srcset="https://zoa.vn/wp-content/uploads/2023/06/ZOA-916x284-1.png 916w, https://zoa.vn/wp-content/uploads/2023/06/ZOA-916x284-1-300x93.png 300w, https://zoa.vn/wp-content/uploads/2023/06/ZOA-916x284-1-768x238.png 768w" sizes="(max-width: 916px) 100vw, 916px" />						
					</div>
								
<style>
#image_229687962 {
  width: 60%;
}
@media (min-width:550px) {
  #image_229687962 {
    width: 30%;
  }
}
@media (min-width:850px) {
  #image_229687962 {
    width: 60%;
  }
}
</style>
	</div>
	

<p><strong>Công ty TNHH Công nghệ VIHAT</strong></p>
<p><strong>MST: 0312577096</strong></p>
	<div id="gap-1767755604" class="gap-element clearfix" style="display:block; height:auto;">
		
<style>
#gap-1767755604 {
  padding-top: 10px;
}
</style>
	</div>
	

<ul>
<li>140 - 142 Đường Số 2 (Vạn Phúc City), Hiệp Bình Phước, Thủ Đức, TP. HCM</li>
<li>Tòa nhà An Hưng Building, 85 - 87 Hoàng Quốc Việt, Nghĩa Đô, Cầu Giấy, Hà Nội</li>
</ul>
<a class="button white is-link is-small"  >
  <i class="icon-phone" aria-hidden="true" ></i>  <span>0901 888 484 (Call us)</span>
  </a>


<a class="button white is-link is-small"  >
  <i class="icon-envelop" aria-hidden="true" ></i>  <span>E-mail</span>
  </a>



		</div>
					</div>

	

	<div id="col-264840615" class="col medium-12 small-12 large-8"  >
				<div class="col-inner"  >
			
			

<div class="row row-small"  id="row-345912332">


	<div id="col-785879753" class="col medium-4 small-12 large-4"  >
				<div class="col-inner"  >
			
			

<h4>Giới thiệu</h4>
<ul>
<li class="bullet-arrow"><a href="https://zoa.vn/zalo-oa-la-gi/" target="_blank" rel="noopener"><span style="font-size: 12.96px;">ZOA là gì?</span></a></li>
<li class="bullet-arrow"><a href="https://zoa.vn/zalo-oa-5-sao-la-gi/" target="_blank" rel="noopener"><span style="font-size: 12.96px;">Zalo OA 5 sao là gì?</span></a></li>
<li class="bullet-arrow"><span style="font-size: 12.96px;">Zalo ZNS là gì?</span></li>
<li class="bullet-arrow"><span style="font-size: 12.96px;">Zalo ZCC là gì?</span></li>
</ul>

		</div>
					</div>

	

	<div id="col-1574465627" class="col medium-4 small-12 large-4"  >
				<div class="col-inner"  >
			
			

<h4>Dịch vụ</h4>
<ul>
<li class="bullet-arrow"><a href="https://omicall.com/tong-dai-ao-la-gi/"><span style="font-size: 12.96px;">Tổng đài ảo</span></a></li>
<li class="bullet-arrow"><a href="https://omicall.com/call-bot/"><span style="font-size: 12.96px;">Callbot</span></a></li>
<li class="bullet-arrow"><a href="https://evoicebrand.com/"><span style="font-size: 12.96px;">Voice Brandname</span></a></li>
<li class="bullet-arrow"><a href="https://khosotongdai.com/"><span style="font-size: 12.96px;">Kho Số Tổng Đài</span></a></li>
<li class="bullet-arrow"><a href="https://esms.vn/"><span style="font-size: 12.96px;">SMS Marketing</span></a></li>
<li class="bullet-arrow"><a href="https://tintk.com/"><span style="font-size: 12.96px;">Kiến Thức Marketing</span></a></li>
<li class="bullet-arrow"><a href="https://ezns.vn/"><span style="font-size: 12.96px;">Zalo ZNS</span></a></li>
<li class="bullet-arrow"><a href="https://zcczalo.com/"><span style="font-size: 12.96px;">Zalo ZCC</span></a></li>
<li class="bullet-arrow"><a href="https://esms.vn/sms-api"><span style="font-size: 90%;">API OTP SMS</span></a></li>
<li class="bullet-arrow"><a href="https://vibermarketing.vn/"><span style="font-size: 12.96px;">Viber Marketing</span></a></li>
<li class="bullet-arrow"><a href="https://ering.vn/"><span style="font-size: 12.96px;">Nhạc Chờ Thương Hiệu</span></a></li>
</ul>

		</div>
					</div>

	

	<div id="col-899143916" class="col medium-4 small-12 large-4"  >
				<div class="col-inner"  >
			
			

<h4>Liên hệ</h4>
<ul>
<li class="bullet-arrow"><a href="https://goo.gl/maps/MxsfSSDJpEQuLP3B7"><span style="font-size: 12.96px;">Bản đồ chỉ đường</span></a></li>
<li class="bullet-arrow"><a href="https://vihat.vn/tuyen-dung/"><span style="font-size: 12.96px;">Tuyển dụng</span></a></li>
<li class="bullet-arrow"><a href="#"><span style="font-size: 12.96px;">Điều khoản</span></a></li>
<li class="bullet-arrow"><a href="#"><span style="font-size: 12.96px;">Chính sách riêng tư</span></a></li>
</ul>

		</div>
					</div>

	

</div>

		</div>
					</div>

	

</div>
<div class="row"  id="row-763854522">


	<div id="col-1927985188" class="col small-12 large-12"  >
				<div class="col-inner"  >
			
			

<div class="is-divider divider clearfix" style="max-width:100%;height:2px;background-color:rgb(255, 255, 255);"></div>


		</div>
				
<style>
#col-1927985188 > .col-inner {
  margin: -30px 0px -30px 0px;
}
</style>
	</div>

	

</div>
<div class="row hide-for-small"  id="row-67907238">


	<div id="col-2122843703" class="col medium-4 small-12 large-4"  >
				<div class="col-inner text-left"  >
			
			

<p>© 2024 Zalo OA Chuẩn 5 Sao</p>

		</div>
					</div>

	

	<div id="col-917044643" class="col medium-4 small-12 large-4"  >
				<div class="col-inner"  >
			
			

<div class="social-icons follow-icons full-width text-center" ><a href="https://www.facebook.com/zoa.vietnam" target="_blank" rel="noopener noreferrer nofollow" data-label="Facebook" class="icon plain facebook tooltip" title="Follow on Facebook" aria-label="Follow on Facebook" ><i class="icon-facebook" ></i></a><a href="https://twitter.com/zoavietnam" data-label="Twitter" target="_blank" rel="noopener noreferrer nofollow" class="icon plain twitter tooltip" title="Follow on Twitter" aria-label="Follow on Twitter" ><i class="icon-twitter" ></i></a><a href="https://www.pinterest.com/zoavietnam/" data-label="Pinterest" target="_blank" rel="noopener noreferrer nofollow" class="icon plain pinterest tooltip" title="Follow on Pinterest" aria-label="Follow on Pinterest" ><i class="icon-pinterest" ></i></a><a href="https://www.youtube.com/@zoa.vietnam/" data-label="YouTube" target="_blank" rel="noopener noreferrer nofollow" class="icon plain youtube tooltip" title="Follow on YouTube" aria-label="Follow on YouTube" ><i class="icon-youtube" ></i></a></div>


		</div>
					</div>

	

	<div id="col-964319306" class="col medium-4 small-12 large-4"  >
				<div class="col-inner text-right"  >
			
			

<a class="button white is-link is-small"  >
    <span>Terms</span>
  </a>


<a class="button white is-link is-small"  >
    <span>Privacy</span>
  </a>


<a class="button white is-link is-small"  >
    <span>Cookies</span>
  </a>



		</div>
					</div>

	

</div>
<div class="row show-for-small"  id="row-1630513255">


	<div id="col-64159240" class="col small-12 large-12"  >
				<div class="col-inner text-center"  >
			
			

<div class="social-icons follow-icons full-width text-center" ><a href="#" target="_blank" rel="noopener noreferrer nofollow" data-label="Facebook" class="icon plain facebook tooltip" title="Follow on Facebook" aria-label="Follow on Facebook" ><i class="icon-facebook" ></i></a><a href="#" target="_blank" rel="noopener noreferrer nofollow" data-label="Instagram" class="icon plain instagram tooltip" title="Follow on Instagram" aria-label="Follow on Instagram" ><i class="icon-instagram" ></i></a><a href="#" data-label="Twitter" target="_blank" rel="noopener noreferrer nofollow" class="icon plain twitter tooltip" title="Follow on Twitter" aria-label="Follow on Twitter" ><i class="icon-twitter" ></i></a><a href="#" data-label="LinkedIn" target="_blank" rel="noopener noreferrer nofollow" class="icon plain linkedin tooltip" title="Follow on LinkedIn" aria-label="Follow on LinkedIn" ><i class="icon-linkedin" ></i></a></div>

	<div id="gap-841096677" class="gap-element clearfix" style="display:block; height:auto;">
		
<style>
#gap-841096677 {
  padding-top: 10px;
}
</style>
	</div>
	

<p>©<br />
 2024 UX Themes</p>
<a class="button white is-link is-small"  >
    <span>Terms</span>
  </a>


<a class="button white is-link is-small"  >
    <span>Privacy</span>
  </a>


<a class="button white is-link is-small"  >
    <span>Cookies</span>
  </a>



		</div>
					</div>

	

</div>

		</div>

		
<style>
#section_845689956 {
  padding-top: 30px;
  padding-bottom: 30px;
  background-color: rgb(39, 54, 71);
}
@media (min-width:550px) {
  #section_845689956 {
    padding-top: 60px;
    padding-bottom: 60px;
  }
}
</style>
	</section>
	
<div class="absolute-footer dark medium-text-center small-text-center">
  <div class="container clearfix">

    
    <div class="footer-primary pull-left">
            <div class="copyright-footer">
        Copyright 2024 © <strong>ZOA.vn</strong>      </div>
          </div>
  </div>
</div>

<a href="#top" class="back-to-top button icon invert plain fixed bottom z-1 is-outline hide-for-medium circle" id="top-link" aria-label="Go to top"><i class="icon-angle-up" ></i></a>

</footer>

</div>

<div id="main-menu" class="mobile-sidebar no-scrollbar mfp-hide">

	
	<div class="sidebar-menu no-scrollbar ">

		
					<ul class="nav nav-sidebar nav-vertical nav-uppercase" data-tab="1">
				<li class="header-search-form search-form html relative has-icon">
	<div class="header-search-form-wrapper">
		<div class="searchform-wrapper ux-search-box relative is-normal"><form method="get" class="searchform" action="https://zoa.vn/" role="search">
		<div class="flex-row relative">
			<div class="flex-col flex-grow">
	   	   <input type="search" class="search-field mb-0" name="s" value="" id="s" placeholder="Search&hellip;" />
			</div>
			<div class="flex-col">
				<button type="submit" class="ux-search-submit submit-button secondary button icon mb-0" aria-label="Submit">
					<i class="icon-search" ></i>				</button>
			</div>
		</div>
    <div class="live-search-results text-left z-top"></div>
</form>
</div>	</div>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-71"><a href="https://zoa.vn/">ZOA.vn</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-67"><a href="#">Bảng giá</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-69"><a href="#">Tìm hiểu</a>
<ul class="sub-menu nav-sidebar-ul children">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-72"><a href="#">Hướng dẫn sử dụng</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-73"><a href="#">Câu chuyện thành công</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-74"><a href="#">Chính sách</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-70"><a href="#">Dịch vụ khác</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-68"><a href="#">Liên hệ</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-65"><a href="https://zoa.vn/blog/">BLOG</a></li>
WooCommerce not Found<li class="header-newsletter-item has-icon">

  <a href="#header-newsletter-signup" class="tooltip" title="Sign up for Newsletter">

    <i class="icon-envelop"></i>
    <span class="header-newsletter-title">
      Newsletter    </span>
  </a>

</li>
<li class="html header-social-icons ml-0">
	<div class="social-icons follow-icons" ><a href="https://www.facebook.com/zoa.vietnam" target="_blank" rel="noopener noreferrer nofollow" data-label="Facebook" class="icon plain facebook tooltip" title="Follow on Facebook" aria-label="Follow on Facebook" ><i class="icon-facebook" ></i></a><a href="https://www.instagram.com/zoavietnam/" target="_blank" rel="noopener noreferrer nofollow" data-label="Instagram" class="icon plain instagram tooltip" title="Follow on Instagram" aria-label="Follow on Instagram" ><i class="icon-instagram" ></i></a><a href="https://twitter.com/zoavietnam" data-label="Twitter" target="_blank" rel="noopener noreferrer nofollow" class="icon plain twitter tooltip" title="Follow on Twitter" aria-label="Follow on Twitter" ><i class="icon-twitter" ></i></a><a href="https://www.pinterest.com/zoavietnam/" data-label="Pinterest" target="_blank" rel="noopener noreferrer nofollow" class="icon plain pinterest tooltip" title="Follow on Pinterest" aria-label="Follow on Pinterest" ><i class="icon-pinterest" ></i></a><a href="https://www.youtube.com/@zoa.vietnam/" data-label="YouTube" target="_blank" rel="noopener noreferrer nofollow" class="icon plain youtube tooltip" title="Follow on YouTube" aria-label="Follow on YouTube" ><i class="icon-youtube" ></i></a></div></li>
<li class="html custom html_topbar_right"><strong class="uppercase">Tặng 10.000 tin nhắn ZNS miễn phí</strong></li><li class="html custom html_top_right_text"><a href="#"><strong>Đăng nhập</strong> </a></li>			</ul>
		
		
	</div>

	
</div>
<div class="hotline-phone-ring-wrap">
	<div class="hotline-phone-ring">
		<div class="hotline-phone-ring-circle"></div>
		<div class="hotline-phone-ring-circle-fill"></div>
		<div class="hotline-phone-ring-img-circle">
		<a href="tel:0901888484" class="pps-btn-img">
			<img src="https://nguyenhung.net/wp-content/uploads/2019/05/icon-call-nh.png" alt="Gọi điện thoại" width="50">
		</a>
		</div>
	</div>
	<div class="hotline-bar">
		<a href="tel:0901888484">
			<span class="text-hotline">0901 888 484</span>
		</a>
	</div>
</div>

<div class="fancybox-hidden" style="display: none;"><div id="contact_form_pop" class="hentry" style="width: 460px; max-width: 100%;">
<div class="wpcf7 no-js" id="wpcf7-f15-o1" lang="vi" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="/signals/iwl.js#wpcf7-f15-o1" method="post" class="wpcf7-form init" aria-label="Form liên hệ" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="15" />
<input type="hidden" name="_wpcf7_version" value="5.8" />
<input type="hidden" name="_wpcf7_locale" value="vi" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f15-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
</div>
<h4>ĐĂNG KÝ THÔNG TIN
</h4>
<p><span class="wpcf7-form-control-wrap" data-name="hovaten"><input size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required name-class" id="name-id" aria-required="true" aria-invalid="false" placeholder="Họ và tên*" value="" type="text" name="hovaten" /></span><br />
<span class="wpcf7-form-control-wrap" data-name="Sodienthoai"><input size="40" class="wpcf7-form-control wpcf7-tel wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-tel phone-class" id="phone-id" aria-required="true" aria-invalid="false" placeholder="Số điện thoại*" value="" type="tel" name="Sodienthoai" /></span><br />
<span class="wpcf7-form-control-wrap" data-name="Email"><input size="40" class="wpcf7-form-control wpcf7-email wpcf7-validates-as-required wpcf7-text wpcf7-validates-as-email email-class" id="email-id" aria-required="true" aria-invalid="false" placeholder="Email*" value="" type="email" name="Email" /></span><br />
<span class="wpcf7-form-control-wrap" data-name="ghichu"><textarea cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea mota-class" id="mota-id" aria-invalid="false" placeholder="Mô tả về doanh nghiệp bạn (tên công ty, lĩnh vực hoạt động, khu vực,...)" name="ghichu"></textarea></span>
</p>
<h5><img src="https://ezns.vn/wp-content/uploads/2022/01/Asset-2.png"  width="15px" /> TẶNG MIỄN PHÍ 10.000 TIN ZALO ZNS
</h5>
<p><span class="wpcf7-form-control-wrap" data-name="Date"><input size="40" class="wpcf7-form-control wpcf7-text hidden" aria-invalid="false" value="" type="text" name="Date" /></span><br />
<span class="wpcf7-form-control-wrap" data-name="Url"><input size="40" class="wpcf7-form-control wpcf7-text hidden" aria-invalid="false" value="" type="text" name="Url" /></span><br />
<input class="wpcf7-form-control wpcf7-submit has-spinner" type="submit" value="Gửi" />
</p><p style="display: none !important;"><label>&#916;<textarea name="_wpcf7_ak_hp_textarea" cols="45" rows="8" maxlength="100"></textarea></label><input type="hidden" id="ak_js_1" name="_wpcf7_ak_js" value="32"/><script>document.getElementById( "ak_js_1" ).setAttribute( "value", ( new Date() ).getTime() );</script></p><div class="wpcf7-response-output" aria-hidden="true"></div>
</form>
</div>
</div></div>
 
<script>
var time=new Date().toLocaleString().replace(",","").replace(/:.. /," ");
var x = document.getElementsByName("Date");
var y = document.getElementsByName("Url");
for (let i = 0; i < x.length; ) {
x[i].setAttribute("value", time);
y[i].setAttribute("value", window.location.href);
i++;
}
</script><style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}body .is-layout-grid{display: grid;}body .is-layout-grid > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
</style>
<script type="text/javascript" src="https://zoa.vn/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.8" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/zoa.vn\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://zoa.vn/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.8" id="contact-form-7-js"></script>
<script type="text/javascript" id="kk-star-ratings-js-extra">
/* <![CDATA[ */
var kk_star_ratings = {"action":"kk-star-ratings","endpoint":"https:\/\/zoa.vn\/wp-admin\/admin-ajax.php","nonce":"ac4628d410"};
/* ]]> */
</script>
<script type="text/javascript" src="https://zoa.vn/wp-content/plugins/kk-star-ratings/src/core/public/js/kk-star-ratings.min.js?ver=5.4.5" id="kk-star-ratings-js"></script>
<script type="text/javascript" src="https://zoa.vn/wp-content/themes/flatsome/inc/extensions/flatsome-live-search/flatsome-live-search.js?ver=3.17.1.1" id="flatsome-live-search-js"></script>
<script type="text/javascript" src="https://zoa.vn/wp-content/plugins/easy-fancybox/fancybox/1.5.4/jquery.fancybox.min.js?ver=6.4.3" id="jquery-fancybox-js"></script>
<script type="text/javascript" id="jquery-fancybox-js-after">
/* <![CDATA[ */
var fb_timeout, fb_opts={'overlayShow':true,'hideOnOverlayClick':true,'showCloseButton':true,'margin':20,'enableEscapeButton':true,'autoScale':true };
if(typeof easy_fancybox_handler==='undefined'){
var easy_fancybox_handler=function(){
jQuery([".nolightbox","a.wp-block-fileesc_html__button","a.pin-it-button","a[href*='pinterest.com\/pin\/create']","a[href*='facebook.com\/share']","a[href*='twitter.com\/share']"].join(',')).addClass('nofancybox');
jQuery('a.fancybox-close').on('click',function(e){e.preventDefault();jQuery.fancybox.close()});
/* IMG */
var fb_IMG_select=jQuery('a[href*=".jpg" i]:not(.nofancybox,li.nofancybox>a),area[href*=".jpg" i]:not(.nofancybox),a[href*=".png" i]:not(.nofancybox,li.nofancybox>a),area[href*=".png" i]:not(.nofancybox),a[href*=".webp" i]:not(.nofancybox,li.nofancybox>a),area[href*=".webp" i]:not(.nofancybox)');
fb_IMG_select.addClass('fancybox image');
var fb_IMG_sections=jQuery('.gallery,.wp-block-gallery,.tiled-gallery,.wp-block-jetpack-tiled-gallery');
fb_IMG_sections.each(function(){jQuery(this).find(fb_IMG_select).attr('rel','gallery-'+fb_IMG_sections.index(this));});
jQuery('a.fancybox,area.fancybox,.fancybox>a').each(function(){jQuery(this).fancybox(jQuery.extend(true,{},fb_opts,{'transitionIn':'elastic','transitionOut':'elastic','opacity':false,'hideOnContentClick':false,'titleShow':true,'titlePosition':'over','titleFromAlt':true,'showNavArrows':true,'enableKeyboardNav':true,'cyclic':false}))});
};};
var easy_fancybox_auto=function(){setTimeout(function(){jQuery('a#fancybox-auto,#fancybox-auto>a').first().trigger('click')},1000);};
jQuery(easy_fancybox_handler);jQuery(document).on('post-load',easy_fancybox_handler);
jQuery(easy_fancybox_auto);
/* ]]> */
</script>
<script type="text/javascript" src="https://zoa.vn/wp-content/plugins/easy-fancybox/vendor/jquery.easing.min.js?ver=1.4.1" id="jquery-easing-js"></script>
<script type="text/javascript" src="https://zoa.vn/wp-content/plugins/easy-fancybox/vendor/jquery.mousewheel.min.js?ver=3.1.13" id="jquery-mousewheel-js"></script>
<script type="text/javascript" src="https://zoa.vn/wp-includes/js/hoverIntent.min.js?ver=1.10.2" id="hoverIntent-js"></script>
<script type="text/javascript" id="flatsome-js-js-extra">
/* <![CDATA[ */
var flatsomeVars = {"theme":{"version":"3.17.1.1"},"ajaxurl":"https:\/\/zoa.vn\/wp-admin\/admin-ajax.php","rtl":"","sticky_height":"70","stickyHeaderHeight":"0","scrollPaddingTop":"0","assets_url":"https:\/\/zoa.vn\/wp-content\/themes\/flatsome\/assets\/","lightbox":{"close_markup":"<button title=\"%title%\" type=\"button\" class=\"mfp-close\"><svg xmlns=\"http:\/\/www.w3.org\/2000\/svg\" width=\"28\" height=\"28\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"feather feather-x\"><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"><\/line><line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"><\/line><\/svg><\/button>","close_btn_inside":false},"user":{"can_edit_pages":false},"i18n":{"mainMenu":"Main Menu","toggleButton":"Toggle"},"options":{"cookie_notice_version":"1","swatches_layout":false,"swatches_disable_deselect":false,"swatches_box_select_event":false,"swatches_box_behavior_selected":false,"swatches_box_update_urls":"1","swatches_box_reset":false,"swatches_box_reset_limited":false,"swatches_box_reset_extent":false,"swatches_box_reset_time":300,"search_result_latency":"0"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://zoa.vn/wp-content/themes/flatsome/assets/js/flatsome.js?ver=f2c57559524d9813afd4" id="flatsome-js-js"></script>
<!--[if IE]>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/intersection-observer-polyfill@0.1.0/dist/IntersectionObserver.js?ver=0.1.0" id="intersection-observer-polyfill-js"></script>
<![endif]-->
<script defer type="text/javascript" src="https://zoa.vn/wp-content/plugins/akismet/_inc/akismet-frontend.js?ver=1687589433" id="akismet-frontend-js"></script>
			<script type="text/javascript" id="wpsp-script-frontend"></script>
			
</body>
</html>
